import { useState } from "react";
import { getTransactions } from "../api/transactionApi";

export default function Transactions() {

    const [nid, setNid]               = useState("");
    const [transactions, setTransactions] = useState([]);
    const [loading, setLoading]       = useState(false);
    const [error, setError]           = useState("");

    function handleSearch() {
        if (!nid) {
            setError("Please enter a National ID");
            return;
        }
        setLoading(true);
        setError("");

        getTransactions(nid)
            .then(data => {
                setTransactions(data);
                setLoading(false);
                console.log(data);
            })
            .catch(err => {
                setError("Error fetching data");
                setLoading(false);
            });
            
    }
    

    return (
        <div style={{ padding: "20px" }}>
            <h2>Customer Transactions</h2>

            {/* Search Input */}
            <input
                type="text"
                placeholder="Enter National ID"
                value={nid}
                onChange={e => setNid(e.target.value)}
            />
            <button onClick={handleSearch}>Search</button>

            {/* Loading */}
            {loading && <p>Loading...</p>}

            {/* Error */}
            {error && <p style={{ color: "red" }}>{error}</p>}

            {/* Results Table */}
            {transactions.length > 0 && (
                <table border="1" style={{ marginTop: "20px", width: "100%" }}>
                    <thead>
                        <tr>
                            <th>Account Number</th>
                            <th>Customer Name</th>
                            <th>Customer Number</th>
                            <th>Local Amount</th>
                            <th>National ID</th>
                            <th>Reference No</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {transactions.map((t, index) => (
                            <tr key={index}>
                                <td>{t.acNo}</td>
                                <td>{t.customerName}</td>
                                <td>{t.customerNo}</td>
                                <td>{t.lcyAmount}</td>
                                <td>{t.nationalId}</td>
                                <td>{t.trnRefNo}</td>
                                <td>{t.trnDt}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}

            {/* No Results */}
            {!loading && transactions.length === 0 && nid && (
                <p>No transactions found</p>
            )}
        </div>
    );
}