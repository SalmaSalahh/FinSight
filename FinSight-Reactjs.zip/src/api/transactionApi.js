const BASE_URL = "http://localhost:8087";  // your spring boot port

// GET transactions by national ID
export const getTransactions = async (nid) => {
    const response = await fetch(BASE_URL + "/transactions/" + nid);
    return response.json();
};